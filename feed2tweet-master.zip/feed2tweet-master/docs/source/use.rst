Use Feed2tweet
==============
After the configuration of Feed2tweet, just launch the following command::

    $ feed2tweet -c /path/to/feed2tweet.ini
