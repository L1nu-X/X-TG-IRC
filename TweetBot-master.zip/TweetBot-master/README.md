# TweetBot
This is A Simple TweetBot to Make Tweets

## Uses
I am sharing this Bot That I used in A Tweet Competition that I Won xD.

This Bot Can Work in CLI Mode Without Selenium
It automates a command line browser called 'lynx'

This does not need Twitter API To Work.
You Can Simply Do By Put Your Account Creds.

This Can be run in Android By Termux

## Requirements
This Bot Was Made Keeping Speed And Resource Usage in Mind.  
So it uses least of requirements.  

```apt install lynx python```

This uses lynx as a commandline browser.  <br>
So You dont even need Any GUI Browser To Make it Work.

### How To Run 

```
git clone https://github.com/TheSpeedX/TweetBot
cd TweetBot
python tweetbot.py
```

This Prevents You From Being Detected As Bot By Doing Human Like interaction And Random Delays.

Note This Was Tested to Be Working on 01-10-2019
