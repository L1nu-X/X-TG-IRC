# RSS Twitter Bot

Reads an rss feed and posts it to twitter

## Setup

Since twitter only allows oauth--even for automated posting by yourself--I had to create an app at http://dev.twitter.com.  They let you generate oauth credentials for your user, which is what I did.

## Requirements

* tweepy
* feedparser
