Documentation for the Feed2tweet project
============================================

You'll find below anything you need to install, configure or run Feed2tweet.

Guide
=====

.. toctree::
   :maxdepth: 2

   install
   configure
   use
   license
   authors


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

