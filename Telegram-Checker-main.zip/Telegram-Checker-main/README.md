# Bin-Checker
A Telegram Bin-Checker Bot to check is your bins are valid or not.

## Additional Information
[![forthebadge made-with-python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

<a href="https://t.me/TgxSupportChat"> <img src="https://img.shields.io/badge/telegram-Support_Group-red?style=social&logo=telegram" alt="Support" /></a>
<a href="https://github.com/TgxBotz/Bin-Checker/stargazers"><img src="https://img.shields.io/github/stars/TgxBotz/Bin-Checker?style=social"></a><a href="https://github.com/TgxBotz/Bin-Checker/fork"><img src="https://img.shields.io/github/forks/TgxBotz/Bin-Checker?label=Fork&logoColor=blue&style=social"></a>	

## Vars
``` 
API_ID - Your Telegram API ID
API_HASH - Your Telegram API HASH
TOKEN - Your Bot Token
```

# Deploy To Heroku
[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/TgxBotz/Bin-Checker)
