# tg-irc-bot

Python bot for relaying IRC messages to Telegram group chats.

API key is located in `API_KEY` environment variable.
