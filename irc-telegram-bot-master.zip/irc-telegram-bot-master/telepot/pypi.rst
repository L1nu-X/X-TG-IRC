.

`Lots of examples and documentations on Github » <https://github.com/nickoala/telepot>`_
-----------------------------------------------------------------------------------------