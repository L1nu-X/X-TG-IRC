# IRC-Bot
IRC Korean Dictionary Bot

Simple bot for IRC channels to scrape definitions from Naver Dictionary for Korean -> English and vice versa.

