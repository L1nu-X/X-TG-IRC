# Inline Query Examples

```
$ python3.5 inline.py <token>   # traditional
$ python3.5 inlinea.py <token>  # async
```

It demonstrates answering inline query and getting chosen inline results.

**[Traditional »](inline.py)**  
**[Async »](inlinea.py)**
