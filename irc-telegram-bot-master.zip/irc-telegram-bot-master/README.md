#Irc-Telegram-Bot

A Bot which relays the msgs of an irc channnel to telegram 
